import './App.css';
import miImagen from './bolitadenieve.png';

function Foto({ modoDia }) {
  return (
    <div className="foto-container">
      <div className="circulo circulo1"
            style={{ backgroundColor: modoDia ? '#f8c4d4' : '#9ae4f9ff' }}></div>
      <div className="circulo circulo2"
            style={{ backgroundColor: modoDia ? '#d14b8f' : '#10abffff' }}></div>
      <div className="circulo circulo3"
            style={{ backgroundColor: modoDia ? '#f4a0c0' : '#87cdffff' }}></div>
      <img src={miImagen} alt="Jellycat" className="imagen-principal" />
    </div>
  )
}

export default Foto;
