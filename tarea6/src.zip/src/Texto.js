import './App.css';

function Texto({ modoDia }) {
  return (
    <div className="texto-principal" style={{ color: modoDia ? '#000000ff' : '#ffffffff' }}>
      <h1>Edición Mágica Navidad</h1>
      <p>
        ¡Es la temporada de abrazos y alegría! Descubre nuestra colección festiva de amigos Jellycat suaves, perfectos para compartir la magia de la Navidad. Desde peluches adorables hasta ideas de regalos encantadores, hay algo para sorprender a todos en la lista de niños buenos.
      </p>
      <button
        className="boton-explorar"
        style={{
          backgroundColor: '#d14b8f',
          color: 'white'
        }}>Explorar más </button>
    </div>
  );
}

export default Texto;
