import './App.css';
import Header from './Header';
import Texto from './Texto';
import Foto from './Foto';
import { useState } from 'react';

function App() {
  const [modoDia, setModoDia] = useState(true)

  return (
    <div className={modoDia ? 'app-dia' : 'app-noche'}>
      <Header modoDia={modoDia} />
      <Foto modoDia={modoDia} />
      <Texto modoDia={modoDia} />
      
      
      <div style={{ position: 'absolute', top: '90px', right: '20px', textAlign: 'center'}}>
        <button
          className="boton-global"
          onClick={() => setModoDia(!modoDia)}
        >
         {modoDia ? 'noche' : 'día'}
        </button>
      </div>
    </div>
  );
}

export default App;
