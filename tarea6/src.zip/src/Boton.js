
function Boton({nombre, modoDia}) {

  return (
    <button
      style={{
        backgroundColor: 'pink',
        color: 'black',
        border: 'none',
        borderRadius: '8px',
        padding: '20px 16px',
        fontSize: '16px',
        cursor: 'pointer'
      }}
    >
      {nombre}
    </button>
  )

}

export default Boton;
