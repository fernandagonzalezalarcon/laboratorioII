import './App.css';
import Boton from './Boton';

function Header() {
  return (
   <div className='header'>
    <Boton nombre="JELLYCAT"/>
    <Boton nombre="MENU"/>
    <Boton nombre="ESPECIAL NAVIDAD"/>
    <Boton nombre="NOSOTROS"/>
    <Boton nombre="REVIEWS"/>
    <Boton nombre="CONTACTOS"/>
   </div>
  )
}

export default Header;
