# Tareas Sección 2

## Tarea 1
* Camila Aguirre Dattoli
* Antonia Parga
* Daniel Moraga
* Viktor Santana
* Joaquin Martinez 
* sebastian bustamante
* Constanza Beneventi
* Fernanda González
* Isabella Marchant M.

## Tarea 2
* BUSTAMANTE GANGAS JUAN SEBASTIÁN http://github.com/juanbustamante94/trabajosemestre-laboratorio/tree/main/trabajo%201
* AGUIRRE DATTOLI CAMILA VALENTINA FRANCISCA https://github.com/camiaguirred/Laboratorio-tecnologico-2-/tree/main/TAREA%202%20CAMILA%20AGUIRRE%20SECCION%202
* BENEVENTI GONZÁLEZ CONSTANZA ANDREA https://github.com/constanzabeneventi-max/lab2/tree/main/tarea1
* DONOSO ARENAS IAN EDUARDO NICOLÁS https://github.com/magiaanegraa/Laboratorio-de-desarrollo-tecnol-gico-2
* IVANOVICH RODRÍGUEZ ZARINKA MILENKA https://github.com/zarinkaivanovich/laboratorio-2/tree/main/tarea%201
* GONZÁLEZ ALARCÓN FERNANDA https://github.com/fernandagonzalezalarcon/laboratorioII/tree/main/Tarea%202
* MARCHANT MARTIN ISABELLA CAROLINA https://github.com/isabellamarchant-lang/Visualizaci-ndatos/tree/main/tarea2
* MARTÍNEZ MUNDY JOAQUÍN VICENTE
* MORAGA BETSALEL DANIEL IGNACIO https://github.com/danielmoraga25/Laboratorio2/tree/main/Tarea%202
* MARTÍNEZ UMAÑA FERNANDA VALENTINA https://github.com/fernandamartinezu/Lab.tencologico.tareas/blob/main/Tarea%20taller.zip
* PARGA LÓPEZ ANTONIA PAZ https://github.com/antoniaparga/tareas/tree/main/tarea%202
* SANTANA VILLARROEL VIKTOR IGNACIO https://github.com/ViktorSantana1937/LabDesTEc-II

## Tarea 3
* AGUIRRE DATTOLI CAMILA VALENTINA FRANCISCA https://github.com/camiaguirred/digr0602-2025/blob/main/Tarea%203%20Laboratorio%20.jpg
* BENEVENTI GONZÁLEZ CONSTANZA ANDREA https://github.com/constanzabeneventi-max/lab2/blob/main/Tarea%203%20Constanza%20Beneventi
* BUSTAMANTE GANGAS JUAN SEBASTIÁN
* DONOSO ARENAS IAN EDUARDO NICOLÁS
* GONZÁLEZ ALARCÓN FERNANDA https://www.notion.so/Tarea-3-26228cb944a780239ffffd1c9e098d43?source=copy_link
* IVANOVICH RODRÍGUEZ ZARINKA MILENKA
* MARTÍNEZ MUNDY JOAQUÍN VICENTE
* MORAGA BETSALEL DANIEL IGNACIO  https://github.com/danielmoraga25/Laboratorio2/tree/main/Tarea%203/Dataset
* PARGA LÓPEZ ANTONIA PAZ
* SANTANA VILLARROEL VIKTOR IGNACIO https://github.com/ViktorSantana1937/LabDesTEc-II/tree/main/Tarea3
* STUVEN CRIADO FELIPE IGNACIO https://github.com/felipeStuven/Laboratorio_tec_2/blob/main/grafico%20aplicaciones%20interactivas.jpg
