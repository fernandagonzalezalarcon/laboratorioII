# Tareas Sección 1

## Tarea 1
* Ian Donoso
* Benjamin Chamorro
* Antonnela Hernandez
* Valentina Medel 
* Tamara Silva 
* Sofía Garrido A.
* Isis Padilla 
* Eric Ponce
* Jo Lizana
* Fransisca Huenullan
* Fernanda Martinez 
* Felipe Stuven https://github.com/felipeStuven/Laboratorio_tec_2/blob/main/grafico%20aplicaciones%20interactivas.jpg
* Javiera Vera
* Constanza Díaz
* alinette galdames

## Tarea 2
* CHAMORRO HENRIQUEZ BENJAMIN IGNACIO https://github.com/Benja-minn/lab2/tree/main/tarea-2
* DÍAZ OLGUÍN CONSTANZA EILIEM https://github.com/ConiDiaz/Lab-Tecnol-gico-II/tree/main/Tarea%202%20
* GALDAMES ARAYA ALINETTE DAMAR https://github.com/alinettegaldames/LAB-TAREAS-ll/tree/main/Tarea
* GARRIDO AGUILERA SOFÍA CATALINA https://github.com/sofig137/Lab-del-profe-Guille-UWU/blob/main/Tarea%202
* GODOY TOBAR ANTONIA
* GONZÁLEZ VEGA ALONDRA SOL
* HERNÁNDEZ SILVA ANTONNELA MELISSA https://github.com/antonnelahernandez/LaboratorioTec_II/tree/antonnelahernandez-patch-1/Tarea2
* HUENULLÁN GONZALEZ FRANSISCA ISIDORA
* PADILLA CARRILLO ISIS CAROLINA https://github.com/IsisPadilla/Curso-Laboratorio/tree/main/Tarea_2
* LIZANA ZÚÑIGA JOSEFA VALENTINA https://github.com/jo-lizana/j0-lab.2_2025-2/tree/main/tarea2
* MEDEL ANDRADE VALENTINA ANTONIA https://github.com/valhimedel/LabDesTec/tree/main/Tarea2
* PONCE NÚÑEZ ERIC ALEJANDRO
* STUVEN CRIADO FELIPE IGNACIO https://github.com/felipeStuven/Laboratorio_tec_2/tree/main/Tarea%202
* SILVA SEREÑO TAMARA SOLEDAD https://github.com/tamarasilva-uf/Curso-laboratorio/tree/main/Tarea-2
* VERA CASTRO JAVIERA ISABEL (https://github.com/Jav1Vera/Tareas/tree/main/Tarea2)

## Tarea 3
Constanza Díaz https://github.com/ConiDiaz/Lab-Tecnol-gico-II/blob/main/Tarea%203
* Vera Castro Javiera Isabel (https://lapis-bugle-f5d.notion.site/TAREA-3-2613ceb82fc480e99de6f0a2df6b0e82?source=copy_link)
