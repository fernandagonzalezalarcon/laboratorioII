# Laboratorio de Desarrollo Tecnológico II
Bienvenides al repositorio oficial del curso Laboratorio de Desarrollo Tecnológico II (VI semestre).

## Horario
* Sección 1: Martes 11:00 – 14:30 hrs
* Sección 2: Martes 15:30 – 16:45 hrs

## Instructor
Guillermo Montecinos, [guillermo.montecinos@uniacc.edu](mailto:guillermo.montecinos@uniacc.edu)

## Comunicación
* La comunicación oficial del curso se realizará mediante el correo institucional de la universidad, y la plataforma e-campus.
* Las entregas del curso se realizarán a través de Github.
* La página oficial del curso se encuentra en el siguiente [link](https://field-mine-ef5.notion.site/DIGR0602-Laboratorio-de-desarrollo-tecnol-gico-II-24951d9cbb998099b876d9be11065f1b?source=copy_link) de Notion.
